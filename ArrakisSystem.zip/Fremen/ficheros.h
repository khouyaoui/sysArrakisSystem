#ifndef FICHEROS_H
#define FICHEROS_H

#include "funciones.h"

void readConfig(char *nombre_f, Config_Data *c);

void liberarStructConfig_Data(Config_Data *c);

#endif